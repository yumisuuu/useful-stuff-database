   __  ______  _                 __          ____           __     __                       
  / / / / / /_(_)___ ___  ____ _/ /____     / __ \___  ____/ /____/ /_____  ____  ___    __ 
 / / / / / __/ / __ `__ \/ __ `/ __/ _ \   / /_/ / _ \/ __  / ___/ __/ __ \/ __ \/ _ \__/ /_
/ /_/ / / /_/ / / / / / / /_/ / /_/  __/  / _, _/  __/ /_/ (__  ) /_/ /_/ / / / /  __/_  __/
\____/_/\__/_/_/ /_/ /_/\__,_/\__/\___/  /_/ |_|\___/\__,_/____/\__/\____/_/ /_/\___/ /_/   

Version 1.4 - Minecraft: Java Edition 1.20.2+                                                         

---------------------------------------------------------- THANK YOU ----------------------------------------------------------

  ...for downloading my RESOURCE PACK!

  I put a lot of passion and effort into creating Ultimate Redstone+, so if you decide to use it in your online content (YouTube
  videos, Twitch streams etc.) I'd be really grateful if you could give me a shout-out or a short mention.
  If you want to support me, simply paste the following text into your description:

  Resource pack: Ultimate Redstone+ by ffreq76
  https://modrinth.com/resourcepack/ultimate-redstone-plus

--------------------------------------------------------- FEATURE LIST --------------------------------------------------------

  • Visual indicators for redstone components:
    > Bee nest: Shows honey level (0-5)
    > Beehive: Shows honey level (0-5)
    > Blast furnace: Shows lit states (off/on)
    > Buttons: Shows pressed state (off/on)
    > Comparator: Shows mode (com/sub)
    > Composter: Shows fill level (0-8)
    > Crafter: Shows states (crafting/triggered)
    > Calibrated sculk sensor: Shows output power & state (active/cooldown/inactive)
    > Cauldron: Shows fill level (0-3)
    > Daylight detector: Shows output power & mode (day/night)
    > Dispenser: Shows direction and powered state
    > Dropper: Shows direction and powered state
    > Detector rail: Shows triggered state (off/on)
    > Furnace: Shows lit states (off/on)
    > Jukebox: Shows music status (playing/stopped)
    > Hopper: Shows direction & state (enabled/disabled)
    > Iron door: Shows triggered state
    > Iron trapdoor: Shows triggered state
    > Lever: Toggle status (off/on)
    > Lectern: Shows powered state (off/on)
    > Note block: Shows pitch and instrument
    > Observer: Indicates direction and activation status
    > Piston & Sticky piston: Shows powered state
    > Pressure plates: Shows pressed state (off/on)
    > Redstone dust: Displays power level (0-15)
    > Repeater: Shows delay (0-4)
    > Respawn anchor: Shows charge status (0-4)
    > Smoker: Shows lit states (off/on)
    > Target: Displays output power level (0-15)
    > Sculk sensor: Shows output power & state (active/cooldown/inactive) 

  • Outline for blocks:
    > Bedrock
    > (Deepslate)Coal ore
    > (Deepslate)Copper ore
    > (Deepslate)Iron ore
    > (Deepslate)Redstone ore
    > (Deepslate)Gold ore
    > (Deepslate)Lapis ore
    > (Deepslate)Diamond ore
    > (Deepslate)Emerald ore
    > Nether quartz ore
    > Nether gold ore

  • Animated outline for blocks:
    > Ancient debris
    > Suspicious sand
    > Suspicious gravel

  • Other:
    > Lava/Water: Shows flow direction
    > Redstone torch: Model from 1.21.2+

----------------------------------------------------------- CREDITS ----------------------------------------------------------- 

  > Based on original textures by Mojang Studios
  > Created and maintained by ffreq76

---------------------------------------------------------- CHANGELOG ----------------------------------------------------------

  • 1.4[03.01.26]
    > Added indicators for the following blocks:
      > Buttons
      > Calibrated sculk sensor
      > Cauldron
      > Detector rail
      > Hopper
      > Iron door
      > Iron trapdoor
      > Lectern
      > Pressure plates
      > Respawn anchor
      > Sculk sensor
    
  • 1.3[13.12.25]
    > Added indicators for the following blocks:
      > Bee nest
      > Beehive
      > Blast furnace
      > Composter
      > Crafter
      > Furnace
      > Smoker

  • 1.2[22.11.25]
    > Added indicators for the following blocks:
      > Note block
    > Added animated outline for the following blocks:
      > Ancient debris
      > Suspicious sand
      > Suspicious gravel

  • 1.1[30.10.25]
    > Added indicators for the following blocks:
      > Comparator
      > Dropper
      > Dispenser
      > Repeater
    > Added outline for the following blocks:
      > (Deepslate)Coal ore
      > (Deepslate)Copper ore
      > (Deepslate)Iron ore
      > (Deepslate)Gold ore
      > (Deepslate)Lapis ore
      > (Deepslate)Diamond ore
      > (Deepslate)Emerald ore
      > Nether quartz ore
      > Nether gold ore
    > Added redstone torch model from 1.21.2+

  • 1.0[26.10.25]
    > Initial release!

-------------------------------------------------------------------------------------------------------------------------------